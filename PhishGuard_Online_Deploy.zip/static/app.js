const form = document.getElementById("scan-form");
const input = document.getElementById("url-input");
const button = document.getElementById("scan-button");
const resultBox = document.getElementById("result");
const emptyState = document.getElementById("empty-state");
const errorBox = document.getElementById("error");
const another = document.getElementById("another");

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}
function setText(id, value) { document.getElementById(id).textContent = value ?? "—"; }
function pillClass(color) { return ["safe","warning","danger"].includes(color) ? color : "warning"; }

function addHistory(item) {
  const body = document.getElementById("history-body");
  const empty = body.querySelector(".empty-row");
  if (empty) empty.remove();
  const tr = document.createElement("tr");
  const values = [item.url, item.verdict, item.risk, item.scanned_at];
  values.forEach((value, i) => {
    const td = document.createElement("td");
    if (i === 0) {
      td.className = "url-cell";
      td.title = value;
      td.textContent = "↗  " + value;
    } else if (i === 1 || i === 2) {
      const pill = document.createElement("span");
      pill.className = "pill " + pillClass(item.color);
      pill.textContent = value;
      td.appendChild(pill);
    } else td.textContent = value;
    tr.appendChild(td);
  });
  body.prepend(tr);
  while (body.rows.length > 30) body.deleteRow(body.rows.length - 1);
}

function renderResult(data) {
  emptyState.classList.add("hidden");
  resultBox.classList.remove("hidden");
  another.classList.remove("hidden");
  const isDanger = data.color === "danger";
  const isWarning = data.color === "warning";
  const color = isDanger ? "#d52c40" : isWarning ? "#d99a19" : "#13a765";
  document.getElementById("gauge").style.setProperty("--gauge-color", color);
  document.getElementById("gauge").style.setProperty("--gauge-width", isDanger ? "90%" : isWarning ? "65%" : "45%");
  document.getElementById("result-symbol").textContent = isDanger ? "!" : isWarning ? "!" : "✓";
  setText("verdict", data.verdict);
  setText("risk", (data.risk || "Unknown") + " Risk");
  document.getElementById("verdict").style.color = color;
  document.getElementById("result-symbol").style.background = color;
  const pill = document.getElementById("status-pill");
  pill.className = "pill " + pillClass(data.color);
  pill.textContent = data.color === "safe" ? "No Threat Detected" : data.color === "danger" ? "Potential Threat" : "Review Required";

  const list = document.getElementById("findings");
  list.replaceChildren();
  (data.findings || []).forEach(text => {
    const li = document.createElement("li");
    li.textContent = text;
    list.appendChild(li);
  });
  if (data.threat_intel_note) {
    const li = document.createElement("li");
    li.textContent = data.threat_intel_note;
    list.appendChild(li);
  }
  setText("vt-stats", data.malicious !== undefined
    ? `VirusTotal engines — malicious: ${data.malicious}, suspicious: ${data.suspicious}, harmless: ${data.harmless}, undetected: ${data.undetected}`
    : data.threat_intel?.message || "");
  setText("detail-domain", data.domain);
  setText("detail-protocol", data.scheme?.toUpperCase());
  setText("detail-method", data.method);
  setText("detail-score", data.score === undefined ? "Threat-intelligence verdict" : `${data.score} (heuristic)`);
  setText("detail-date", data.scanned_at);
  const link = document.getElementById("visit-link");
  link.href = data.url;
  link.classList.remove("hidden");
  const notice = document.getElementById("notice");
  notice.textContent = data.notice || "Treat results as guidance, not a guarantee.";
  notice.classList.remove("hidden");
  addHistory(data);
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  errorBox.classList.add("hidden");
  button.disabled = true;
  button.textContent = "Scanning…";
  try {
    const response = await fetch("/api/scan", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({url: input.value, use_virustotal: document.getElementById("use-vt").checked})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Scan failed. Please try again.");
    renderResult(data);
  } catch (error) {
    showError(error.message || "Could not connect to the local scanner.");
  } finally {
    button.disabled = false;
    button.innerHTML = "<span>⌕</span> Scan URL";
  }
});

another.addEventListener("click", () => {
  input.value = "";
  resultBox.classList.add("hidden");
  another.classList.add("hidden");
  document.getElementById("notice").classList.add("hidden");
  emptyState.classList.remove("hidden");
  input.focus();
});

document.getElementById("clear-history").addEventListener("click", async () => {
  try {
    const response = await fetch("/api/clear-history", {method:"POST"});
    if (!response.ok) throw new Error();
    const body = document.getElementById("history-body");
    body.replaceChildren();
    const tr = document.createElement("tr");
    tr.className = "empty-row";
    const td = document.createElement("td");
    td.colSpan = 4;
    td.textContent = "Your scanned URLs will appear here.";
    tr.appendChild(td);
    body.appendChild(tr);
  } catch {
    showError("Could not clear history.");
  }
});
